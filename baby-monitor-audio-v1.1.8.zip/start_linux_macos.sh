#!/bin/bash
# Baby Monitor Audio - Portable Launcher
echo ""
echo "==========================================="
echo "  👶 Baby Monitor Audio v1.1.8"
echo "  Portable Edition"
echo "==========================================="
echo ""

echo "📦 Checking Python installation..."
if ! command -v python3 &> /dev/null && ! command -v python &> /dev/null; then
    echo "❌ ERROR: Python not found!"
    echo ""
    echo "Please install Python 3.6 or higher"
    echo "Ubuntu/Debian: sudo apt install python3 python3-pip"
    echo "macOS: brew install python3"
    echo ""
    read -p "Press Enter to exit"
    exit 1
fi

PYTHON_CMD="python3"
if ! command -v python3 &> /dev/null; then
    PYTHON_CMD="python"
fi

echo "✅ Python found ($PYTHON_CMD)"
echo ""

echo "📦 Installing/Checking dependencies..."
echo "This may take a moment..."
echo ""

$PYTHON_CMD -m pip install -r requirements.txt --quiet

if [ $? -ne 0 ]; then
    echo "❌ ERROR: Failed to install dependencies"
    echo ""
    echo "Try running: $PYTHON_CMD -m pip install -r requirements.txt"
    echo ""
    read -p "Press Enter to exit"
    exit 1
fi

echo "✅ Dependencies installed"
echo ""

echo "🚀 Starting Baby Monitor..."
echo "Close this terminal to stop the monitor"
echo ""

$PYTHON_CMD BabyMonitor.pyw

echo ""
echo "👶 Baby Monitor stopped"
read -p "Press Enter to exit"
