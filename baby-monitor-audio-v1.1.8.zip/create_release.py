#!/usr/bin/env python3
"""
Automated Release Creator for Baby Monitor
Creates GitHub releases with installers and assets
"""

import os
import sys
import json
import subprocess
import zipfile
import shutil
from pathlib import Path
import requests
from datetime import datetime

class ReleaseCreator:
    def __init__(self, repo_owner="elgodox", repo_name="baby-monitor-audio"):
        self.repo_owner = repo_owner
        self.repo_name = repo_name
        self.api_base = f"https://api.github.com/repos/{repo_owner}/{repo_name}"
        self.token = os.getenv('GITHUB_TOKEN')

        if not self.token:
            print("❌ GITHUB_TOKEN environment variable not set")
            print("   Get a token from: https://github.com/settings/tokens")
            print("   Set it with: $env:GITHUB_TOKEN='your_token_here'")
            sys.exit(1)

        self.headers = {
            'Authorization': f'token {self.token}',
            'Accept': 'application/vnd.github.v3+json'
        }

    def run_command(self, cmd, description=""):
        """Run a command and return success"""
        if description:
            print(f"🔄 {description}...")
        try:
            result = subprocess.run(cmd, shell=True, check=True,
                                  capture_output=True, text=True)
            if description:
                print(f"✅ {description} completado")
            return True, result.stdout.strip()
        except subprocess.CalledProcessError as e:
            print(f"❌ Error: {e}")
            print(f"Output: {e.output}")
            return False, ""

    def get_latest_commit(self):
        """Get the latest commit hash"""
        success, output = self.run_command("git rev-parse HEAD", "Obteniendo commit hash")
        return output if success else None

    def get_version_from_commit(self):
        """Generate version from commit count"""
        success, output = self.run_command("git rev-list --count HEAD", "Contando commits")
        if success:
            return f"v1.1.{output}"
        return "v1.1.0"

    def create_installer_zip(self, version):
        """Create a portable ZIP installer"""
        installer_dir = f"baby-monitor-{version}"
        zip_name = f"{installer_dir}.zip"

        print(f"🔄 Creando installer ZIP: {zip_name}")

        # Create installer directory
        if os.path.exists(installer_dir):
            shutil.rmtree(installer_dir)
        os.makedirs(installer_dir)

        # Copy essential files
        files_to_copy = [
            'BabyMonitor.pyw',
            'README.md',
            'requirements.txt',
            'LICENSE'
        ]

        for file in files_to_copy:
            if os.path.exists(file):
                shutil.copy2(file, installer_dir)

        # Create run script
        run_script = f"""#!/bin/bash
# Baby Monitor Launcher
echo "🚀 Starting Baby Monitor {version}"
echo "📦 Checking dependencies..."

if ! command -v python &> /dev/null; then
    echo "❌ Python not found. Please install Python 3.6+"
    read -p "Press Enter to exit"
    exit 1
fi

# Install dependencies if needed
if [ ! -d "venv" ]; then
    echo "📥 Creating virtual environment..."
    python -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
else
    source venv/bin/activate
fi

# Run the application
echo "👶 Starting Baby Monitor..."
python BabyMonitor.pyw

deactivate
"""
        with open(f"{installer_dir}/run.sh", 'w') as f:
            f.write(run_script)
        os.chmod(f"{installer_dir}/run.sh", 0o755)

        # Create Windows batch file
        batch_script = f"""@echo off
REM Baby Monitor Launcher for Windows
echo 🚀 Starting Baby Monitor {version}
echo 📦 Checking dependencies...

python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python not found. Please install Python 3.6+
    pause
    exit /b 1
)

REM Install dependencies if needed
if not exist venv (
    echo 📥 Creating virtual environment...
    python -m venv venv
    call venv\\Scripts\\activate.bat
    pip install -r requirements.txt
) else (
    call venv\\Scripts\\activate.bat
)

REM Run the application
echo 👶 Starting Baby Monitor...
python BabyMonitor.pyw

deactivate
pause
"""
        with open(f"{installer_dir}/run.bat", 'w') as f:
            f.write(batch_script)

        # Create ZIP file
        with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(installer_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arc_name = os.path.relpath(file_path, installer_dir)
                    zipf.write(file_path, arc_name)

        # Cleanup
        shutil.rmtree(installer_dir)

        print(f"✅ Installer ZIP creado: {zip_name}")
        return zip_name

    def create_release(self, version, commit_hash):
        """Create a GitHub release"""
        print(f"🔄 Creando release {version}...")

        # Create ZIP installer
        zip_file = self.create_installer_zip(version)

        # Prepare release data
        release_data = {
            "tag_name": version,
            "target_commitish": commit_hash,
            "name": f"Baby Monitor {version} - Audio & Multi-Camera",
            "body": f"""# 👶 Baby Monitor {version}

## 🚀 New Features
- **🎤 Real-time Audio Streaming** with sounddevice
- **📹 Multi-Camera Detection** and selection
- **🔄 Dynamic Device Switching** without restart
- **⚡ Graceful Fallbacks** for missing devices
- **🌙 Modern Dark UI** with status indicators

## 📦 What's Included
- Complete Python application
- Portable ZIP installer
- Cross-platform support (Windows/macOS/Linux)
- All dependencies included

## 🛠️ Installation
1. Download and extract the ZIP file
2. Run `run.bat` (Windows) or `run.sh` (macOS/Linux)
3. The app will automatically install dependencies and start

## 🎯 Quick Start
- Select your camera from the dropdown
- Click START to begin monitoring
- Scan QR code or share the link
- Audio streams automatically when available

**Commit:** `{commit_hash[:8]}`

---
*Enhanced fork with audio and multi-camera support*
""",
            "draft": False,
            "prerelease": False
        }

        # Create release
        response = requests.post(f"{self.api_base}/releases",
                               headers=self.headers,
                               data=json.dumps(release_data))

        if response.status_code == 201:
            release_info = response.json()
            release_id = release_info['id']
            upload_url = release_info['upload_url'].replace('{?name,label}', '')

            print(f"✅ Release creado: {version}")

            # Upload ZIP asset
            if os.path.exists(zip_file):
                self.upload_asset(upload_url, zip_file, f"application/zip")

            return release_info['html_url']
        else:
            print(f"❌ Error creando release: {response.status_code}")
            print(response.text)
            return None

    def upload_asset(self, upload_url, file_path, content_type):
        """Upload a release asset"""
        filename = os.path.basename(file_path)

        print(f"🔄 Subiendo asset: {filename}")

        headers = self.headers.copy()
        headers['Content-Type'] = content_type

        with open(file_path, 'rb') as f:
            response = requests.post(f"{upload_url}?name={filename}",
                                   headers=headers, data=f)

        if response.status_code == 201:
            print(f"✅ Asset subido: {filename}")
            return True
        else:
            print(f"❌ Error subiendo asset: {response.status_code}")
            return False

def main():
    print("🚀 Baby Monitor Release Creator")
    print("=" * 40)

    creator = ReleaseCreator()

    # Get version info
    commit_hash = creator.get_latest_commit()
    version = creator.get_version_from_commit()

    print(f"📋 Información del release:")
    print(f"   Versión: {version}")
    print(f"   Commit: {commit_hash[:8] if commit_hash else 'N/A'}")
    print(f"   Repo: {creator.repo_owner}/{creator.repo_name}")

    if input("\n¿Crear release? (y/N): ").lower() == 'y':
        release_url = creator.create_release(version, commit_hash or "HEAD")

        if release_url:
            print("
🎉 ¡Release creado exitosamente!"            print(f"📁 URL: {release_url}")
            print("🔗 Comparte este enlace con tus usuarios"
        else:
            print("❌ Error creando el release")
    else:
        print("❌ Cancelado")

if __name__ == "__main__":
    main()